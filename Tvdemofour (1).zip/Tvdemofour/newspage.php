<?php /* Template Name: News Catagory Page */ ?>
<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>

<!------------ Main Body Section  Start-------------->

<section class="main_body_section">
    
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
        
        <div class="row">
            <div class="col-md-9 col-sm-8">
               
               <section class="page_section">

                   
                    <?php if($themesdealer['newscat-one-button'] == 1 ): ?>
					
                    <div class="row">
                        
                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-one'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-one'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-one'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-two'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-two'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-two'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                    </div>

				
					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_01')?>
					</section>
				
					<?php endif; ?>   
					<?php if($themesdealer['newscat-one-button'] == 2 ): ?>
					<?php endif; ?>
                    
                     <?php if($themesdealer['newscat-three-button'] == 1 ): ?>
					 
                    <div class="news_section_two">
                        <div class="row">
                        
                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-three'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-three'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-three'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-four'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-four'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-four'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                    </div>
                    </div>

					
					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_02')?>
					</section>
					
					<?php endif; ?>   
					<?php if($themesdealer['newscat-three-button'] == 2 ): ?>
					<?php endif; ?>
                    
					<?php if($themesdealer['newscat-five-button'] == 1 ): ?>
                    <div class="news_section_two">
                        <div class="row">
                        
                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-five'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-five'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-five'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-six'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-six'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-six'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                    </div>
                    </div>

				
					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_03')?>
					</section>
					
					<?php endif; ?>   
					<?php if($themesdealer['newscat-five-button'] == 2 ): ?>
					<?php endif; ?>
					
					<?php if($themesdealer['newscat-seven-button'] == 1 ): ?>
                    
					<div class="news_section_two">
							<div class="row">
							
							<div class="col-md-6 col-sm-6">
								
								<?php
								$cat = $themesdealer['newscat-seven'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
								<div class="cat_title">
									<i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
								</div>
								
								<?php
								$cat = $themesdealer['newscat-seven'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat);
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' =>1,
									'offset' => 0,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="box_shadow_two">
									<div class="leadnews_image">
										<div class="news_video_sec">
											<a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
										</div>
										
										<div class="content_padding">
										<div class="lead_height_1">
											<div class="heading_1">
												<a href="<?php the_permalink()?>"><?php the_title() ?></a>
											 </div>
										 </div>

										 </div>


									</div>
								</div>
								
								<?php endwhile?>
								
								
								<?php
								$category_name = get_the_category_by_id($cat);
								$how_cat= $themesdealer['how_post_newscat-seven'];
								$total_how_cat=$how_cat-1;
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $total_how_cat,
									'offset' => 1,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="tab_sec">
									
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
											the_post_thumbnail();}
											else{?>
										<div class="tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
									
									<div class="heading_2">
										<div class="tab_padding">
											<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
										</div>
									</div>
								</div>
								
								<?php endwhile?>
								
						  </div>


							<div class="col-md-6 col-sm-6">
								
								<?php
								$cat = $themesdealer['newscat-eight'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
								<div class="cat_title">
									<i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
								</div>
								
								<?php
								$cat = $themesdealer['newscat-eight'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat);
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' =>1,
									'offset' => 0,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="box_shadow_two">
									<div class="leadnews_image">
										<div class="news_video_sec">
											<a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
										</div>
										
										<div class="content_padding">
										<div class="lead_height_1">
											<div class="heading_1">
												<a href="<?php the_permalink()?>"><?php the_title() ?></a>
											 </div>
										 </div>

										 </div>


									</div>
								</div>
								
								<?php endwhile?>
								
								
								<?php
								$category_name = get_the_category_by_id($cat);
								$how_cat= $themesdealer['how_post_newscat-eight'];
								$total_how_cat=$how_cat-1;
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $total_how_cat,
									'offset' => 1,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="tab_sec">
									
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
											the_post_thumbnail();}
											else{?>
										<div class="tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
									
									<div class="heading_2">
										<div class="tab_padding">
											<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
										</div>
									</div>
								</div>
								
								<?php endwhile?>
								
						  </div>


						</div>
						</div>

					
					<section class="widget_section">
					<?php dynamic_sidebar('widget_area_04')?>
					</section> 
				 
					<?php endif; ?>   
					<?php if($themesdealer['newscat-seven-button'] == 2 ): ?>
					<?php endif; ?>
                    
					<?php if($themesdealer['newscat-nine-button'] == 1 ): ?>
					
					 <div class="news_section_two">
							<div class="row">
							
							<div class="col-md-6 col-sm-6">
								
								<?php
								$cat = $themesdealer['newscat-nine'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
								<div class="cat_title">
									<i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
								</div>
								
								<?php
								$cat = $themesdealer['newscat-nine'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat);
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' =>1,
									'offset' => 0,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="box_shadow_two">
									<div class="leadnews_image">
										<div class="news_video_sec">
											<a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
										</div>
										
										<div class="content_padding">
										<div class="lead_height_1">
											<div class="heading_1">
												<a href="<?php the_permalink()?>"><?php the_title() ?></a>
											 </div>
										 </div>

										 </div>


									</div>
								</div>
								
								<?php endwhile?>
								
								
								<?php
								$category_name = get_the_category_by_id($cat);
								$how_cat= $themesdealer['how_post_newscat-nine'];
								$total_how_cat=$how_cat-1;
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $total_how_cat,
									'offset' => 1,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="tab_sec">
									
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
											the_post_thumbnail();}
											else{?>
										<div class="tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
									
									<div class="heading_2">
										<div class="tab_padding">
											<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
										</div>
									</div>
								</div>
								
								<?php endwhile?>
								
						  </div>


							<div class="col-md-6 col-sm-6">
								
								<?php
								$cat = $themesdealer['newscat-ten'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
								<div class="cat_title">
									<i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
								</div>
								
								<?php
								$cat = $themesdealer['newscat-ten'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat);
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' =>1,
									'offset' => 0,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="box_shadow_two">
									<div class="leadnews_image">
										<div class="news_video_sec">
											<a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
										</div>
										
										<div class="content_padding">
										<div class="lead_height_1">
											<div class="heading_1">
												<a href="<?php the_permalink()?>"><?php the_title() ?></a>
											 </div>
										 </div>

										 </div>


									</div>
								</div>
								
								<?php endwhile?>
								
								
								<?php
								$category_name = get_the_category_by_id($cat);
								$how_cat= $themesdealer['how_post_newscat-ten'];
								$total_how_cat=$how_cat-1;
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $total_how_cat,
									'offset' => 1,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="tab_sec">
									
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
											the_post_thumbnail();}
											else{?>
										<div class="tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
									
									<div class="heading_2">
										<div class="tab_padding">
											<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
										</div>
									</div>
								</div>
								
								<?php endwhile?>
								
						  </div>


						</div>
						</div>

					
					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_05')?>
					</section> 
					
					<?php endif; ?>   
					<?php if($themesdealer['newscat-nine-button'] == 2 ): ?>
					<?php endif; ?>
					
					<?php if($themesdealer['newscat-eleven-button'] == 1 ): ?>
					
					<div class="news_section_two">
                        <div class="row">
                        
                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-eleven'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-eleven'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-eleven'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                        <div class="col-md-6 col-sm-6">
                            
							<?php
							$cat = $themesdealer['newscat-twelve'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat); 
							?>
							
							<div class="cat_title">
                                <i class="fa fa-newspaper-o"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                            </div>
							
							<?php
							$cat = $themesdealer['newscat-twelve'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="box_shadow_two">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    
                                    <div class="content_padding">
                                    <div class="lead_height_1">
                                        <div class="heading_1">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                         </div>
                                     </div>

                                     </div>


                                </div>
                            </div>
							
							<?php endwhile?>
							
							
							<?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_newscat-twelve'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                            <div class="tab_sec">
								
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="tabimage_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
                            
                      </div>


                    </div>
                    </div>
					
				   <section class="widget_section">
						<?php dynamic_sidebar('widget_area_06')?>
					</section> 
				   
					<?php endif; ?>   
					<?php if($themesdealer['newscat-eleven-button'] == 2 ): ?>
					<?php endif; ?>

               </section> 

            </div>
            <div class="col-md-3 col-sm-4">
                
                <div class="tab-header">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo $themesdealer['last'] ?></a></li>
						<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"><?php echo $themesdealer['popular'] ?></a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div role="tabpanel" class="tab-pane in active" id="tab21">

                            <div class="news-titletab">
                                
								<?php							 
									$lastnews = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $themesdealer['lastpost'],
									'offset' =>0,
									));
									while($lastnews->have_posts()) : $lastnews->the_post();?>
									
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>
                                 
								 <?php endwhile ?>
								 
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                            <div class="news-titletab">
                                
								<?php	
								query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC');
								if (have_posts()) : while (have_posts()) : the_post();
								?>
								
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>

								<?php
								endwhile; endif;
								wp_reset_query();
								?>
										
                            </div>                                          
                        </div>
                    </div>
                </div>

                <!------------ Tab Close -------------->

                <section class="single_widget_section">
					<?php dynamic_sidebar('page_sidebar')?>
				</section>


                









            </div>
        </div>

    </div>
</section>

<?php get_footer(); 
			?>