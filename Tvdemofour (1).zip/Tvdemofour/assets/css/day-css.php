<?php global $themesdealer; ?>
<style>

body { 
    font-family: SolaimanLipiNormal;
    font-size:<?php echo $themesdealer['body-font']['font-size']?>;
	line-height:<?php echo $themesdealer['body-font']['line-height']?>;  
    background: <?php echo $themesdealer['body-background']?>; 
}
.container.website_body {
    background: <?php echo $themesdealer['main-background']?>; 
    box-shadow: 0 0 5px #c4c3c3;
}
.live_screen_section {
	background: <?php echo $themesdealer['tv-background']?>; 
}
.logo_banner_sec {
    background: <?php echo $themesdealer['dder-background']?>;
}
.scrool_section {
    background: <?php echo $themesdealer['scrool-background']?>; 
    margin-top: 3px;
}
.scrool_section .container {
    padding: 0px;
}
.page_scrool_section {
    background: #e9ecec;
    margin-top: 3px;
}
.page_scrool_section .container {
    padding: 0px;
}
.col-md-2.col-sm-3.front_scrool {
    width: 15%;
    color: <?php echo $themesdealer['scrool-font']['color']?>;
    text-align: center;
    background: <?php echo $themesdealer['scrool-title']?>; 
    height: 45px;
    font-size: 20px;
    line-height: 45px;
}
.col-md-9.col-sm-7.behind_scrool {
    color: #fffb00;
    font-size: 19px;
    line-height: 45px;
    height: 45px;
    padding-left: 0px;
    padding-right: 0px;
    background: <?php echo $themesdealer['scrool-background']?>; 
}
.col-md-9.col-sm-7.behind_scrool a {
    color: #e8e8e8;
    font-size: 19px;
    line-height: 45px;
    height: 45px;
}
.col-md-9.col-sm-7.behind_scrool a {
    text-decoration: none;
}
.scrool_image {
    background: <?php echo $themesdealer['scrool-title']?>; 
    height: 45px;
    width: 9.999%
}
.scrool_image img{
    width: 100%;
    height: 45px;
    padding :0;
}

.top_hdr_menu {
	display: block ruby;
}
.top_header_section {
    background: <?php echo $themesdealer['top_headder-background']?>; 
    padding: 9px 0px;
}
.top_hdr_menu span {
    color: <?php echo $themesdealer['top_headder-font']['color']?>;
    text-align: left;
    border-right: 1px solid<?php echo $themesdealer['top_headder-font']['color']?>;
    padding-right: 10px;
    margin-right: -13px;
}

.top_hdr_menu span2 {
	border-left: 1px solid<?php echo $themesdealer['top_headder-font']['color']?>;
	padding-left: 15px;
	margin-left: 15px;
}

.top_hdr_menu span2 a {
    color: <?php echo $themesdealer['top_headder-font']['color']?>;
    text-decoration:none;
	font-size: 17px;
}
.top_hdr_menu span2 a:hover {
    color: #f7ff00;
    transition: .5s;
}
.top_hdr_menu span i{
    color: <?php echo $themesdealer['top_headder-font']['color']?>;
    font-size: 20px;
    padding-right: 6px;
}
.top_hdr_menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
    text-align: left;
}
.top_hdr_menu ul li {
    display: inline-block;
    margin-left: 10px;
    border-left: 1px solid<?php echo $themesdealer['top_headder-font']['color']?>;
    padding-left: 15px;
}
.top_hdr_menu ul li:first-child {
    border:none;
}

.top_hdr_menu ul li a {
    font-size: 17px;
    color: <?php echo $themesdealer['top_headder-font']['color']?>;
    text-decoration: none;
}
.top_hdr_menu ul li a:hover {
    color: #f7ff00;
    transition: .5s;
}

.livetv_menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
    text-align:center;
}
.livetv_menu ul li {
    display: inline-block;
    margin-left: 15px;
    border-left: 1px solid<?php echo $themesdealer['menu-font']['color']?>;
    padding-left: 15px;
}
.livetv_menu ul li:first-child {
    border:none;
}
.livetv_menu ul li a {
    font-size: 22px;
    color: <?php echo $themesdealer['menu-font']['color']?>;
    text-decoration: none;
}
.livetv_menu ul li a:hover {
    color: #F2F1F0;
    transition: .5s;
}
.liveheader_section{
    background: <?php echo $themesdealer['menu-background']?>;
	padding:10px 5px;
	border-top:2px solid#333;
}

.hdr_menu_section .container {
    padding: 0px;
}
.hdr_menu_section{
    background: <?php echo $themesdealer['menu-background']?>;
}

.dropdown-menu > li > a {
	padding: 6px 12px !important;
	border-bottom: 1px solid #800404;
}
.caret {
	border-top: 7px dashed!important;
	border-right: 6px solid transparent!important;
	border-left: 6px solid transparent!important;
}
.menu_bottom { 
    background: <?php echo $themesdealer['menu-background']?>;
 }
.mainmenu .collapse ul ul,
.mainmenu .collapse ul ul.dropdown-menu{
    background:#9A1515;
}
.mainmenu .collapse ul ul ul,
.mainmenu .collapse ul ul ul.dropdown-menu{
    background:#860E0E;
}
.menu_area .menu_bottom .mainmenu a , .navbar-default .navbar-nav > li > a {
     color: <?php echo $themesdealer['menu-font']['color']?>;
    font-size: 17px;
    text-transform: capitalize;
    padding: 13px 10px;
    border-right:1px solid#9A1515;
}

.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, 
.navbar-default .navbar-nav > .active > a:focus {
    color: #fff !important;
    margin: 0px;
    background-color: #9A1515;
}

.heading_1 {
    font-size: 16px;
    line-height: 20px;
    color:<?php echo $themesdealer['heading-01-font']['color']?>;
}
.heading_1 a {
    font-size:<?php echo $themesdealer['heading-01-font']['font-size']?>;
	line-height:<?php echo $themesdealer['heading-01-font']['line-height']?>;
	font-weight:<?php echo $themesdealer['heading-01-font']['font-weight']?>;	
	color:<?php echo $themesdealer['heading-01-font']['color']?>;
    text-decoration: none;
}
.heading_1 a:hover {
    color: #FF3428;
    transition: .5s;
}

.heading_2 i {
	font-size: 22px;
	color: #088e95;
}
.heading_2 a {
    font-size:<?php echo $themesdealer['heading-02-font']['font-size']?>;
	line-height:<?php echo $themesdealer['heading-02-font']['line-height']?>;
	font-weight:<?php echo $themesdealer['heading-02-font']['font-weight']?>;	
	color:<?php echo $themesdealer['heading-02-font']['color']?>;
    text-decoration: none;
}
.heading_2 a:hover {
    color: #088e95;
    transition: .5s;
}

.heading_3 a {
    font-size:<?php echo $themesdealer['heading-03-font']['font-size']?>;
	line-height:<?php echo $themesdealer['heading-03-font']['line-height']?>;
	font-weight:<?php echo $themesdealer['heading-03-font']['font-weight']?>;	
	color:<?php echo $themesdealer['heading-03-font']['color']?>;
    text-decoration: none;
}
.heading_3 a:hover {
    color: #179bd7;
    transition: .5s;
}

.widget_area h3 {
    background: <?php echo $themesdealer['catagory-background']?>;
    padding: 7px 10px;
    font-size:<?php echo $themesdealer['catagory-font']['font-size']?>;
	color:<?php echo $themesdealer['catagory-font']['color']?>;
    font-weight: 400;
    border-left: 5px solid #234859;
    border-bottom: 2px solid #234859;
    box-shadow: 1px 1px 6px rgba(179, 173, 173, 0.3);
    margin-bottom: 10px;
}
.cat_title {
    background: <?php echo $themesdealer['catagory-background']?>;
    padding: 7px 10px;
    font-size:<?php echo $themesdealer['catagory-font']['font-size']?>;
	color:<?php echo $themesdealer['catagory-font']['color']?>;
    font-weight: 400;
    border-left: 5px solid #234859;
    border-bottom: 2px solid #234859;
    box-shadow: 1px 1px 6px rgba(179, 173, 173, 0.3);
    margin-bottom: 10px;
}
.cat_title a {
    text-decoration: none;
    font-size:<?php echo $themesdealer['catagory-font']['font-size']?>;
	color:<?php echo $themesdealer['catagory-font']['color']?>;
    font-weight: 400;
}

.video_cat_title {
    background: <?php echo $themesdealer['videocatagory-background']?>;
    padding: 7px 10px;
    color: #fbeb06;
    font-size: 20px;
    font-weight: 400;
    border-bottom: 2px solid #e1d304;
    box-shadow: 1px 1px 6px rgba(179, 173, 173, 0.3);
}
.video_cat_title a {
    text-decoration: none;
    font-size:<?php echo $themesdealer['videocatagory-font']['font-size']?>;
	color:<?php echo $themesdealer['videocatagory-font']['color']?>;
    font-weight: 400;
}

.author_name_profile {
    background: <?php echo $themesdealer['catagory-background']?>;
    padding: 15px 10px 25px 10px;
    overflow: hidden;
}
.archive_title {
    background: <?php echo $themesdealer['catagory-background']?>;
    padding: 7px;
    font-size: 18px;
    color: #fff;
    margin-bottom: 15px;
}
.comment_title {
	background: <?php echo $themesdealer['catagory-background']?>;
	padding:8px 10px;
	font-size: 20px;
	color: #fff;
}

.footer_logo_section {
	background: <?php echo $themesdealer['lfooter-color']?>;
	padding: 10px 0;
	border-top: 2px solid <?php echo $themesdealer['catagory-background']?>;
}
.footer_menu_section {
	background: <?php echo $themesdealer['mfooter-color']?>;
	padding: 20px 0px 10px 0px;
}
.footer-menu ul{
    list-style: none;
    padding: 0;
    padding-left: 10px;
    margin: 0;
}
.footer-menu ul li {
	padding-bottom: 10px;
	font-size: 18px;
}
.footer-menu ul li a{
    color: <?php echo $themesdealer['mfooter-font']['color']?>;
    text-decoration: none;
}
.footer-menu li a:hover{
    color:#FFD100;
}


.footer_content_section {
	background: <?php echo $themesdealer['afooter-color']?>;
	padding: 22px 0px;
}
.ftr_text{
    text-align: left;
    font-size: 17px;
    color: <?php echo $themesdealer['afooter-font']['color']?>; 
}




.btm_footer_section {
	background: <?php echo $themesdealer['afooterr-color']?>;
	padding: 10px 0;
}
.copy{
    font-size: 16px;
    color: <?php echo $themesdealer['bottomfoot-font']['color']?>; 
}
.design_developed {
    font-size: 16px;
    color: <?php echo $themesdealer['bottomfoot-font']['color']?>; 
    text-align: right;
}
.design_developed a {
    color: #fbd405;
    font-weight: 600;
    font-size: 18px;
    text-decoration: none;
}

/**==================================
         go to top css start
 ==================================**/ 

.TopUp{
    width:50px; 
    height:50px;
    padding:10px;  
    background: <?php echo $themesdealer['menu-background']?>;
    position:fixed;
    right:25px;
    bottom:70px;
    border-radius: 5%;
    z-index: 999;
}
.TopUp i.fa{
    font-size: 35px;
    color: #fff;
    font-weight: 600;
    top:5px;
    display: block;
    position: absolute;
    right: 13px;
}
.TopUp:hover{
    text-decoration:none;

}




</style>