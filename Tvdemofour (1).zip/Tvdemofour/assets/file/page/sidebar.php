<?php global $themesdealer; ?>
<div class="col-md-3 col-sm-3">
                
                <!------------ Tab Start -------------->

                <div class="tab-header">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo $themesdealer['last'] ?></a></li>
						<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"><?php echo $themesdealer['popular'] ?></a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div role="tabpanel" class="tab-pane in active" id="tab21">

                            <div class="news-titletab">
                                
								<?php							 
									$lastnews = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $themesdealer['lastpost'],
									'offset' =>0,
									));
									while($lastnews->have_posts()) : $lastnews->the_post();?>
									
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>
                                 
								 <?php endwhile ?>
								 
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                            <div class="news-titletab">
                                
								<?php	
								query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC');
								if (have_posts()) : while (have_posts()) : the_post();
								?>
								
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>

								<?php
								endwhile; endif;
								wp_reset_query();
								?>
										
                            </div>                                          
                        </div>
                    </div>
                </div>
				
				<?php if($themesdealer['pfacebook'] == 1 ): ?>
							
				<div class="cat_title">
					 <?php echo $themesdealer['facebook-title'] ?>  
				</div>
								
				<div class="fb-root">
					<script>(function(d, s, id) {
					  var js, fjs = d.getElementsByTagName(s)[0];
					  if (d.getElementById(id)) return;
					  js = d.createElement(s); js.id = id;
					  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
					  fjs.parentNode.insertBefore(js, fjs);
					}(document, 'script', 'facebook-jssdk'));</script>
					<div class="fb-page" data-href="<?php echo $themesdealer['pfacebook-link']['pface-url']; ?>" data-tabs="timeline" data-width="<?php echo $themesdealer['pfacebook-width']?>" data-height="<?php echo $themesdealer['pfacebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
				 </div>
			
				<?php endif; ?>   
				<?php if($themesdealer['pfacebook'] == 2 ): ?>
				<?php endif; ?>
				
                <!------------ Tab Close -------------->

                <section class="sidebar_widget_sec">
					<?php dynamic_sidebar('widget_side_01')?>
				</section>
				
				
				<?php if($themesdealer['oside-show'] == 1): ?>
				
                <!------------ Sidebar Cat One  Start -------------->

                <?php
				$cat = $themesdealer['oside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
				<?php
				$cat = $themesdealer['oside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat);
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' =>1,
					'offset' => 0,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
				<div class="box_shadow_two">
                    <div class="leadnews_image news_image_cat">
                        <div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                        <div class="lead_height_1">
                            <div class="heading_2">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
                         </div>

                         </div>


                    </div>
                </div>
				
				<?php endwhile?>
				
				<?php
				$category_name = get_the_category_by_id($cat);
				$how_cat= $themesdealer['how_post_sideo'];
				$total_how_cat=$how_cat-1;
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => $total_how_cat,
					'offset' => 1,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
                <div class="tab_sec">
								
					<a href="<?php the_permalink()?>">
						<?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
						<div class="tabimage_video">
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
								echo wp_oembed_get( $url );?>
							</div>
						</div>
						<i class="fa fa-play" aria-hidden="true"></i>
						<?php } ?>
					</a>
					
					<div class="heading_3">
						<div class="tab_padding">
							<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
						</div>
					</div>
				</div>
				
				<?php endwhile?>
				
				<?php endif; ?>   
				<?php if($themesdealer['oside-show'] == 2 ): ?>
				<?php endif; ?>
				
				
				<?php if($themesdealer['tside-show'] == 1 ): ?>
				
				<!------------ Sidebar Cat Two  Start -------------->
				
				<?php
				$cat = $themesdealer['tside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
                <div class="box_shadow">
                    <div class="leadnews_image news_image_cat">
                        
						<?php
						$cat = $themesdealer['tside-cat'];
						$category_name = get_the_category_by_id($cat);
						$category_name_link = get_category_link($cat);
						$themes_dealer = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' =>1,
							'offset' => 0,
							'cat' => $cat,

						));
						while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
						
						<div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                            <div class="heading_2 lead_height_1">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                             </div>
							 
							 <?php endwhile?>
							 
							 <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_sidet'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                             <div class="heading_2 lead_height_2 border">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
							 
                             <?php endwhile?>
							 
                        </div>
                    </div>
                </div>

                <?php endif; ?>   
				<?php if($themesdealer['tside-show'] == 2 ): ?>
				<?php endif; ?>

				
				<?php if($themesdealer['thside-show'] == 1 ): ?>
                <!------------ Sidebar Cat Three  Start -------------->

                <?php
				$cat = $themesdealer['thside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
				<?php
				$cat = $themesdealer['thside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat);
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' =>1,
					'offset' => 0,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
				<div class="box_shadow_two">
                    <div class="leadnews_image news_image_cat">
                        <div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                        <div class="lead_height_1">
                            <div class="heading_2">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
                         </div>

                         </div>


                    </div>
                </div>
				
				<?php endwhile?>
				
				<?php
				$category_name = get_the_category_by_id($cat);
				$how_cat= $themesdealer['how_post_sideth'];
				$total_how_cat=$how_cat-1;
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => $total_how_cat,
					'offset' => 1,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
                <div class="tab_sec">
								
					<a href="<?php the_permalink()?>">
						<?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
						<div class="tabimage_video">
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
								echo wp_oembed_get( $url );?>
							</div>
						</div>
						<i class="fa fa-play" aria-hidden="true"></i>
						<?php } ?>
					</a>
					
					<div class="heading_3">
						<div class="tab_padding">
							<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
						</div>
					</div>
				</div>
				
				<?php endwhile?>
				
				<?php endif; ?>   
				<?php if($themesdealer['thside-show'] == 2 ): ?>
				<?php endif; ?>
				
				<!------------ Sidebar Cat Four  Start -------------->
				
				   
				<?php if($themesdealer['frside-show'] == 1 ): ?>
				
				<?php
				$cat = $themesdealer['frside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
                <div class="box_shadow">
                    <div class="leadnews_image news_image_cat">
                        
						<?php
						$cat = $themesdealer['frside-cat'];
						$category_name = get_the_category_by_id($cat);
						$category_name_link = get_category_link($cat);
						$themes_dealer = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' =>1,
							'offset' => 0,
							'cat' => $cat,

						));
						while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
						
						<div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                            <div class="heading_2 lead_height_1">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                             </div>
							 
							 <?php endwhile?>
							 
							 <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_sidefr'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                             <div class="heading_2 lead_height_2 border">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
							 
                             <?php endwhile?>
							 
                        </div>
                    </div>
                </div>
				
				<?php endif; ?>   
				<?php if($themesdealer['frside-show'] == 2 ): ?>
				<?php endif; ?>
				<!------------ Tab Close -------------->

                <section class="sidebar_widget_sec">
					<?php dynamic_sidebar('widget_side_02')?>
				</section>
				
				
                <!------------ Sidebar Cat Five  Start -------------->
				
				  
				<?php if($themesdealer['feside-show'] == 1 ): ?>
				
                <?php
				$cat = $themesdealer['feside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
				<?php
				$cat = $themesdealer['feside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat);
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' =>1,
					'offset' => 0,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
				<div class="box_shadow_two">
                    <div class="leadnews_image news_image_cat">
                        <div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                        <div class="lead_height_1">
                            <div class="heading_2">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
                         </div>

                         </div>


                    </div>
                </div>
				
				<?php endwhile?>
				
				<?php
				$category_name = get_the_category_by_id($cat);
				$how_cat= $themesdealer['how_post_sidefe'];
				$total_how_cat=$how_cat-1;
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => $total_how_cat,
					'offset' => 1,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
                <div class="tab_sec">
								
					<a href="<?php the_permalink()?>">
						<?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
						<div class="tabimage_video">
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
								echo wp_oembed_get( $url );?>
							</div>
						</div>
						<i class="fa fa-play" aria-hidden="true"></i>
						<?php } ?>
					</a>
					
					<div class="heading_3">
						<div class="tab_padding">
							<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
						</div>
					</div>
				</div>
				
				<?php endwhile?>
				
				<?php endif; ?>   
				<?php if($themesdealer['feside-show'] == 2 ): ?>
				<?php endif; ?>
				
				
				<!------------ Sidebar Cat Six  Start -------------->
				
				
				<?php if($themesdealer['sside-show'] == 1 ): ?>
				
				<?php
				$cat = $themesdealer['sside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
                <div class="box_shadow">
                    <div class="leadnews_image news_image_cat">
                        
						<?php
						$cat = $themesdealer['sside-cat'];
						$category_name = get_the_category_by_id($cat);
						$category_name_link = get_category_link($cat);
						$themes_dealer = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' =>1,
							'offset' => 0,
							'cat' => $cat,

						));
						while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
						
						<div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                            <div class="heading_2 lead_height_1">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                             </div>
							 
							 <?php endwhile?>
							 
							 <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_sides'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                             <div class="heading_2 lead_height_2 border">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
							 
                             <?php endwhile?>
							 
                        </div>
                    </div>
                </div>

                
				<?php endif; ?>   
				<?php if($themesdealer['sside-show'] == 2 ): ?>
				<?php endif; ?>

                <!------------ Sidebar Cat Seven  Start -------------->
				
				  
				<?php if($themesdealer['snside-show'] == 1 ): ?>
				
                <?php
				$cat = $themesdealer['snside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
				<?php
				$cat = $themesdealer['snside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat);
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' =>1,
					'offset' => 0,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
				<div class="box_shadow_two">
                    <div class="leadnews_image news_image_cat">
                        <div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                        <div class="lead_height_1">
                            <div class="heading_2">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
                         </div>

                         </div>


                    </div>
                </div>
				
				<?php endwhile?>
				
				<?php
				$category_name = get_the_category_by_id($cat);
				$how_cat= $themesdealer['how_post_sidesn'];
				$total_how_cat=$how_cat-1;
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => $total_how_cat,
					'offset' => 1,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
                <div class="tab_sec">
								
					<a href="<?php the_permalink()?>">
						<?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
						<div class="tabimage_video">
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
								echo wp_oembed_get( $url );?>
							</div>
						</div>
						<i class="fa fa-play" aria-hidden="true"></i>
						<?php } ?>
					</a>
					
					<div class="heading_3">
						<div class="tab_padding">
							<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
						</div>
					</div>
				</div>
				
				<?php endwhile?>
				
				<?php endif; ?>   
				<?php if($themesdealer['snside-show'] == 2 ): ?>
				<?php endif; ?>
				
				<!------------ Sidebar Cat Eight  Start -------------->
				
				 
				<?php if($themesdealer['etside-show'] == 1 ): ?>
				
				<?php
				$cat = $themesdealer['etside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
                <div class="box_shadow">
                    <div class="leadnews_image news_image_cat">
                        
						<?php
						$cat = $themesdealer['etside-cat'];
						$category_name = get_the_category_by_id($cat);
						$category_name_link = get_category_link($cat);
						$themes_dealer = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' =>1,
							'offset' => 0,
							'cat' => $cat,

						));
						while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
						
						<div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                            <div class="heading_2 lead_height_1">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                             </div>
							 
							 <?php endwhile?>
							 
							 <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_sideet'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                             <div class="heading_2 lead_height_2 border">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
							 
                             <?php endwhile?>
							 
                        </div>
                    </div>
                </div>
				
				<!------------ Tab Close -------------->
				
				<?php endif; ?>   
				<?php if($themesdealer['etside-show'] == 2 ): ?>
				<?php endif; ?>
				
                <section class="sidebar_widget_sec">
					<?php dynamic_sidebar('widget_side_03')?>
				</section>

                <!------------ Sidebar Cat Nine  Start -------------->
				
				  
				<?php if($themesdealer['neside-show'] == 1 ): ?>
				
                <?php
				$cat = $themesdealer['neside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
				<?php
				$cat = $themesdealer['neside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat);
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' =>1,
					'offset' => 0,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
				<div class="box_shadow_two">
                    <div class="leadnews_image news_image_cat">
                        <div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                        <div class="lead_height_1">
                            <div class="heading_2">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
                         </div>

                         </div>


                    </div>
                </div>
				
				<?php endwhile?>
				
				<?php
				$category_name = get_the_category_by_id($cat);
				$how_cat= $themesdealer['how_post_sidene'];
				$total_how_cat=$how_cat-1;
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => $total_how_cat,
					'offset' => 1,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
                <div class="tab_sec">
								
					<a href="<?php the_permalink()?>">
						<?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
						<div class="tabimage_video">
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
								echo wp_oembed_get( $url );?>
							</div>
						</div>
						<i class="fa fa-play" aria-hidden="true"></i>
						<?php } ?>
					</a>
					
					<div class="heading_3">
						<div class="tab_padding">
							<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
						</div>
					</div>
				</div>
				
				<?php endwhile?>
				
				<?php endif; ?>   
				<?php if($themesdealer['neside-show'] == 2 ): ?>
				<?php endif; ?>
				
				<!------------ Sidebar Cat Ten  Start -------------->
				
				 
				<?php if($themesdealer['tnside-show'] == 1 ): ?>
				
				<?php
				$cat = $themesdealer['tnside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
                <div class="box_shadow">
                    <div class="leadnews_image news_image_cat">
                        
						<?php
						$cat = $themesdealer['tnside-cat'];
						$category_name = get_the_category_by_id($cat);
						$category_name_link = get_category_link($cat);
						$themes_dealer = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' =>1,
							'offset' => 0,
							'cat' => $cat,

						));
						while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
						
						<div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                            <div class="heading_2 lead_height_1">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                             </div>
							 
							 <?php endwhile?>
							 
							 <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_sidetn'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                             <div class="heading_2 lead_height_2 border">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
							 
                             <?php endwhile?>
							 
                        </div>
                    </div>
                </div>

                
				<?php endif; ?>   
				<?php if($themesdealer['tnside-show'] == 2 ): ?>
				<?php endif; ?>

                <!------------ Sidebar Cat Eleven  Start -------------->

				
				  
				<?php if($themesdealer['enside-show'] == 1 ): ?>
				
                <?php
				$cat = $themesdealer['enside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
				<?php
				$cat = $themesdealer['enside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat);
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' =>1,
					'offset' => 0,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
				<div class="box_shadow_two">
                    <div class="leadnews_image news_image_cat">
                        <div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                        <div class="lead_height_1">
                            <div class="heading_2">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
                         </div>

                         </div>


                    </div>
                </div>
				
				<?php endwhile?>
				
				<?php
				$category_name = get_the_category_by_id($cat);
				$how_cat= $themesdealer['how_post_sideen'];
				$total_how_cat=$how_cat-1;
				$themes_dealer = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => $total_how_cat,
					'offset' => 1,
					'cat' => $cat,

				));
				while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
				
                <div class="tab_sec">
								
					<a href="<?php the_permalink()?>">
						<?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
						<div class="tabimage_video">
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
								echo wp_oembed_get( $url );?>
							</div>
						</div>
						<i class="fa fa-play" aria-hidden="true"></i>
						<?php } ?>
					</a>
					
					<div class="heading_3">
						<div class="tab_padding">
							<a href="<?php the_permalink()?>"><?php the_title() ?></a> 
						</div>
					</div>
				</div>
				
				<?php endwhile?>
				
				<?php endif; ?>   
				<?php if($themesdealer['enside-show'] == 2 ): ?>
				<?php endif; ?>
				
				<!------------ Sidebar Cat Twelve  Start -------------->
				
				  
				<?php if($themesdealer['twside-show'] == 1 ): ?>
				
				<?php
				$cat = $themesdealer['twside-cat'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
				<div class="cat_title">
					<i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
				</div>
				
                <div class="box_shadow">
                    <div class="leadnews_image news_image_cat">
                        
						<?php
						$cat = $themesdealer['twside-cat'];
						$category_name = get_the_category_by_id($cat);
						$category_name_link = get_category_link($cat);
						$themes_dealer = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' =>1,
							'offset' => 0,
							'cat' => $cat,

						));
						while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
						
						<div class="news_video_sec">
                            <a href="<?php the_permalink()?>">
								<?php if(has_post_thumbnail()){ 
									the_post_thumbnail();}
									else{?>
								<div class="news_video">
									<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
										<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
										echo wp_oembed_get( $url );?>
									</div>
								</div>
								<i class="fa fa-play" aria-hidden="true"></i>
								<?php } ?>
							</a>
                        </div>
                        
                        <div class="content_padding">
                            <div class="heading_2 lead_height_1">
                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                             </div>
							 
							 <?php endwhile?>
							 
							 <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['how_post_sidetw'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                             <div class="heading_2 lead_height_2 border">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                             </div>
							 
                             <?php endwhile?>
							 
                        </div>
                    </div>
                </div>
				
				
				<?php endif; ?>   
				<?php if($themesdealer['twside-show'] == 2 ): ?>
				<?php endif; ?>
				<!------------ Tab Close -------------->

                <section class="sidebar_widget_sec">
					<?php dynamic_sidebar('widget_side_04')?>
				</section>




            </div>