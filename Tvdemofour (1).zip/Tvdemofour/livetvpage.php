<?php /* Template Name: Live Tv Page */ ?>
<?php get_header() ?>
   <?php global $themesdealer ?>
<section class="live_screen_section">

<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	

<div class="row">
<div class="col-md-12">


<?php if($themesdealer['logo-show'] == 1 ): ?>

<div class="logo_left">
	<a href="<?php bloginfo('url'); ?>"><img src="<?php echo $themesdealer['tv_logo_upload']['url']?>"></a>
</div>


<?php endif; ?>   
<?php if($themesdealer['logo-show'] == 2 ): ?>						
<?php endif; ?>


<?php 
$themes_dealer = new WP_Query(array(
'post_type' => 'live',
'posts_per_page' => 1, ));
while($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>

<div class="">

<?php $live_tv_option_type = get_post_meta(get_the_ID(),'select_live_tv_option', true); ?>

<?php if($live_tv_option_type == 'youtube_single_video') : ?>
<?php $single_video = get_post_meta(get_the_ID(),'youtube_single_video', true); ?>
<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
<iframe  src="https://www.youtube.com/embed/<?php echo $single_video; ?>?autoplay=1&amp;loop=1&amp;controls=0&amp;amp&amp;rel=0;&amp;showinfo=0;" width="640" height="360" frameborder="0" allowfullscreen="allowfullscreen" allow="autoplay"></iframe>
</div>
<?php endif; ?> 

<?php if($live_tv_option_type == 'youtube_playlist_video') : ?>
<?php $first_video = get_post_meta(get_the_ID(),'youtube_playlist_one', true); ?>
<?php $second_video = get_post_meta(get_the_ID(),'youtube_playlist_second', true); ?>
<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
<iframe  src="https://www.youtube.com/embed/<?php echo $first_video; ?>?autoplay=1&amp;loop=1&amp;controls=0&amp;amp&amp;rel=0;&amp;showinfo=0;list=<?php echo $second_video; ?>" width="640" height="360" frameborder="0" allowfullscreen="allowfullscreen" allow="autoplay"></iframe>
</div>
<?php endif; ?> 


<?php if($live_tv_option_type == 'facebookkk_link') : ?>
<?php $facebook_linkk = get_post_meta(get_the_ID(),'facebook_link', true); ?>

<!-- Load Facebook SDK for JavaScript -->
  <div id="fb-root"></div>
  <script>
	window.fbAsyncInit = function() {
	  FB.init({
		appId      : '{your-app-id}',
		xfbml      : true,
		version    : 'v2.5'
	  });

	  // Get Embedded Video Player API Instance
	  var my_video_player;
	  FB.Event.subscribe('xfbml.ready', function(msg) {
		if (msg.type === 'video') {
		  my_video_player = msg.instance;
		  my_video_player.unmute();
		}
	  });
	};

	(function(d, s, id){
	   var js, fjs = d.getElementsByTagName(s)[0];
	   if (d.getElementById(id)) {return;}
	   js = d.createElement(s); js.id = id;
	   js.src = "//connect.facebook.net/en_US/sdk.js";
	   fjs.parentNode.insertBefore(js, fjs);
	 }(document, 'script', 'facebook-jssdk'));
  </script>

  <!-- Your embedded video player code -->
  <div  
	class="fb-video" 
	data-href="<?php echo $facebook_linkk;?>" 
	data-width="auto" 
	data-autoplay="true"
	data-allowfullscreen="true"
	data-controls="false"></div>
	
<?php endif; ?>

							
<?php if($live_tv_option_type == 'streaming_server') : ?>
<?php $streaming = get_post_meta(get_the_ID(),'streaming', true); ?>
<div id="player"></div>
<script>
	flowplayer('#player', {		
		autoplay: true,
		share: true,
		fullscreen: true,
		// iOS allows only native fullscreen from within iframes
		native_fullscreen: true,
		live: true,  // set if it's a live stream
		ratio: 9/16, // set the aspect ratio of the stream

		clip: {
			sources: [
				// path to the HLS m3u8
				{ type: "application/x-mpegurl", src: "<?php echo $streaming?>"},
			]
		},
	});
</script>
<?php endif; ?> 

	<?php if($live_tv_option_type == 'own_server') : ?>
	<?php $sserver_link = get_post_meta(get_the_ID(),'serverfile', true); ?>
<video width="100%" height="auto" controls autoplay>
  <source src="<?php echo $sserver_link; ?>" type="video/mp4">
</video>
<?php endif; ?> 

</div>

<?php endwhile; ?>



</div>
</div>



</div>
<?php get_template_part('scrool');?>
<section class="liveheader_section">
<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	
    
    <div class="row">
        <div class="col-md-12 col-sm-2">
            <div class="livetv_menu">

				<?php
					wp_nav_menu( array('theme_location' => 'tvpage',
				)); ?>

            </div>
        </div>                  
                         
    </div>

</div>
</section>


<section class="footer_logo_section">
<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	

	<div class="row">
		<div class="col-md-3 col-sm-4">
			<div class="footer_logo">
				<a href="<?php bloginfo('url'); ?>"><img src="<?php echo $themesdealer['ftlogo_upload']['url']?>" alt="Logo" width="100%"></a>
			</div>
		</div>
		<div class="col-md-9 col-sm-8"></div>
	</div>

</div>
</section>

<section class="footer_content_section">
<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	

	<div class="row">
		<div class="col-md-8 col-sm-8">
			<div class="ftr_text">
				<?php echo $themesdealer['address']?>
			</div>
		</div>
		<div class="col-md-4 col-sm-4">
			<?php if($themesdealer['facebook'] == 1 ): ?>		
			<div class="fb-root">
				<script>(function(d, s, id) {
				  var js, fjs = d.getElementsByTagName(s)[0];
				  if (d.getElementById(id)) return;
				  js = d.createElement(s); js.id = id;
				  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
				  fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>
				<div class="fb-page" data-href="<?php echo $themesdealer['facebook-link']['face-url']; ?>" data-tabs="timeline" data-width="<?php echo $themesdealer['facebook-width']?>" data-height="<?php echo $themesdealer['facebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
			 </div>
		
			<?php endif; ?>   
			<?php if($themesdealer['facebook'] == 2 ): ?>
			<?php endif; ?>
			
			<section class="widget_section">
				<?php dynamic_sidebar('footer_widget')?>
			</section>
	
		</div>
	</div>

</div>
</section>
<?php 
get_template_part('/framework/codestyles/funtion');
?>