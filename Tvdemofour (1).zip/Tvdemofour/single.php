<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>

<!------------ Main Body Section  Start-------------->

<section class="main_body_section">
    
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
        
        <div class="row">
			
			<section class="singletop_widget_section">
				<div class="col-md-12 col-sm-12">
					<?php dynamic_sidebar('single_top')?>
				</div>
			</section>
			
            <div class="col-md-8 col-sm-8">
               
               <section class="page_section">             
						
				   <?php if(have_posts()) : ?>
						<?php while(have_posts()) : the_post(); ?>
					
                   <div class="archive_title">
                        <a href="<?php bloginfo('url');?>"><i class="fa fa-home" aria-hidden="true"></i> / </a><?php the_category(', '); ?>  
                    </div>

                    <div class="single_title">
                        <?php the_title();?>
                    </div>


                    <div class="reportar_view_social_sec">
                           <div class="row">
                               <div class="col-md-8 col-sm-12">
                                   
                                   <div class="row">
                                        <div class="col-md-2 col-sm-2 col-xs-3">
                                            <div class="reporter_image">
                                               <?php echo get_avatar(get_the_author_meta('ID'),$default );?>
                                            </div>
                                        </div>
                                        <div class="col-md-10 col-sm-10 col-xs-9">
                                            <div class="reporter_name">
                                                <i class="fa fa-pencil-square-o"></i> <?php the_author_posts_link(''); ?> 
												<?php if($themesdealer['view-tab'] == 1 ): ?> 
												
												<span>  
												
												<?php if($themesdealer['content-translatetor'] == 1 ): ?> 
												/ <?php setPostViews(get_the_ID()); ?>
												<?php $view= getPostViews(get_the_ID()); 
												echo bn_number($view);?>
												<?php endif; ?>			   
													<?php if($themesdealer['content-translatetor'] == 2 ): ?>
													<?php setPostViews(get_the_ID()); ?> <?php echo getPostViews(get_the_ID()); ?>
												<?php endif; ?>
												<?php echo $themesdealer['count'];?> 
												
												</span>
												
												<?php endif; ?>			   
												<?php if($themesdealer['view-tab'] == 2 ): ?>
												<?php endif; ?>
                                            </div>
                                            <div class="update_time">
                                                <?php echo $themesdealer['update'];?> 
												
												<?php if($themesdealer['content-translatetor'] ==1 ): ?>
												<?php 
												
												$currentDate = get_the_time("l, j F, Y, g:i a");
												$engDATE = array(1,2,3,4,5,6,7,8,9,0,'January','February','March','April','May','June','July','August','September','October','November','December','Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','am','pm');
												$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০','জানুয়ারী','ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর','শনিবার','রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','পূর্বাহ্ন','অপরাহ্ন' 
												);
												
												$convertedDATE = str_replace($engDATE, $bangDATE, $currentDate);
												echo "$convertedDATE";
												?>
												<?php endif; ?>
														<?php if($themesdealer['content-translatetor'] == 2 ): ?>
												<?php echo get_the_time("l, F j, Y"); ?>
												<?php endif; ?> 
                                            </div>
                                            

                                        </div>
                                    </div>

                               </div>
                               <div class="col-md-4 col-sm-12">
                                   <div class="social_title">
                                       <?php echo $themesdealer['social_title'] ?>
                                   </div>
                                       <ul class="social_Share_icon">
                                            <li><a href="http://www.facebook.com/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" class="sngl_facebook" target="_blank"> <i class="fa fa-facebook"></i></a></li>
                                            <li><a href="https://twitter.com/share?text=<?php echo urlencode( get_the_title() ); ?>" class="sngl_twitter" target="_blank"> <i class="fa fa-twitter"></i></a></li>
                                            <li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title(); ?>" class="sngl_google-plus" target="_blank"> <i class="fa fa-linkedin"></i></a></li>                        
                                            <li><a href="http://digg.com/submit?url=<?php the_permalink(); ?>" class="sngl_digg" target="_blank"> <i class="fa fa-digg"></i></a></li>
                                            <li><a href="http://www.pinterest.com/pin/create/button/?url=<?php echo urlencode(get_permalink()); ?>" class="sngl_pinterest" target="_blank"> <i class="fa fa-pinterest"></i></a></li>
                                            <li> <p class="sngl_print" target="_blank">
												<?php if(function_exists('wp_print')) { print_link(); } ?> </p> </li>
                                        </ul>

                                        
                               </div>
                           </div> 
                        </div>

                        <div class="single_img">
                            <?php if(has_post_thumbnail()){ 
							the_post_thumbnail();}
							else{?>
							<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
								<?php 
								$url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) );
								echo wp_oembed_get( $url );
								?>
							</div>
							<?php } ?>
							<div class="content">
							<?php 
							   $caption = get_post(get_post_thumbnail_id())->post_excerpt;
								if ($caption): ?>
								 <div class="caption"><?php echo $caption ?> </div>
							   <?php endif; ?>
							</div>
                        </div>

                        <div class="single_dtails">

                            <?php the_content();?>
							
                        </div>
						
						<?php endwhile;?>
						<?php endif;?> 
						
                        <section class="single_widget_section">
							<?php dynamic_sidebar('single_middle')?>
						</section> 
							
						<!-- *(view-tab show or hide open)*-->	
						<?php if($themesdealer['coment'] ==1 ): ?>
								<div class="single_dtails"> 
								<div class="comment_title"> আপনার মতামত লিখুন :</div>
								   <?php comments_template(); ?>
								   </div>
								<?php endif; ?> 
						 <?php if($themesdealer['coment'] == 2 ): ?>
							   <?php endif; ?>
						<!-- *(view-tab show or hide close)*-->
				
				
                         <div class="cat_title">
                            <?php echo $themesdealer['more-news-category']?>
                        </div>

                        <div class="row">
                        
						<?php $orig_post = $post;
							global $post;
							$categories = get_the_category($post->ID);
							if ($categories) {
							$category_ids = array();
							foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;

							$args=array(
							'category__in' => $category_ids,
							'post__not_in' => array($post->ID),
							'posts_per_page'=> 3, // Number of related posts that will be shown.
							);

							$my_query = new wp_query( $args );
							if( $my_query->have_posts() ) {

							while( $my_query->have_posts() ) {
							$my_query->the_post(); ?>
							
                        <div class="col-md-4 col-sm-4">
                            <div class="box_shadow">
                                <div class="leadnews_image singlemore_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    <div class="content_padding">
                                        <div class="lead_height_1">
                                            <div class="heading_1">
                                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             </div>
                        </div>
                        
						<?php
						}    }    } 
						$post = $orig_post;
						wp_reset_query(); ?>

                    </div>

                    <div class="row">
                        
						<?php $orig_post = $post;
							global $post;
							$categories = get_the_category($post->ID);
							if ($categories) {
							$category_ids = array();
							foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;

							$args=array(
							'category__in' => $category_ids,
							'post__not_in' => array($post->ID),
							'posts_per_page'=> 3, // Number of related posts that will be shown.
							'offset'=> 3,
							);
							$my_query = new wp_query( $args );
							if( $my_query->have_posts() ) {

							while( $my_query->have_posts() ) {
							$my_query->the_post(); ?>
							
                        <div class="col-md-4 col-sm-4">
                            <div class="box_shadow">
                                <div class="leadnews_image singlemore_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    <div class="content_padding">
                                        <div class="lead_height_1">
                                            <div class="heading_1">
                                                <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             </div>
                        </div>
                        
						<?php
						}    }    } 
						$post = $orig_post;
						wp_reset_query(); ?>

                    </div>

                    <section class="single_widget_section">
						<?php dynamic_sidebar('single_buttom')?>
					</section>

               </section> 

            </div>
            <div class="col-md-4 col-sm-4">
                
                <!------------ Tab Start -------------->

                <div class="tab-header">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo $themesdealer['last'] ?></a></li>
						<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"><?php echo $themesdealer['popular'] ?></a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div role="tabpanel" class="tab-pane in active" id="tab21">

                            <div class="news-titletab">
                                
								<?php							 
									$lastnews = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $themesdealer['lastpost'],
									'offset' =>0,
									));
									while($lastnews->have_posts()) : $lastnews->the_post();?>
								
								<div class="single_tab_sec">
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
										<div class="single_tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>

                            <div class="single_tab_border"></div>
							
							<?php endwhile ?>
							
                            


                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                            <div class="news-titletab">
                                <?php	
								query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC');
								if (have_posts()) : while (have_posts()) : the_post();
								?>
								
								<div class="single_tab_sec">
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
										<div class="single_tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>

                            <div class="single_tab_border"></div>
							
							<?php
								endwhile; endif;
								wp_reset_query();
								?>
								
								

                            
                            </div>                                          
                        </div>
                    </div>
                </div>
				
				<?php if($themesdealer['pfacebook'] == 1 ): ?>
							
				<div class="cat_title">
					 <?php echo $themesdealer['facebook-title'] ?>  
				</div>
								
				<div class="fb-root">
					<script>(function(d, s, id) {
					  var js, fjs = d.getElementsByTagName(s)[0];
					  if (d.getElementById(id)) return;
					  js = d.createElement(s); js.id = id;
					  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
					  fjs.parentNode.insertBefore(js, fjs);
					}(document, 'script', 'facebook-jssdk'));</script>
					<div class="fb-page" data-href="<?php echo $themesdealer['pfacebook-link']['pface-url']; ?>" data-tabs="timeline" data-width="<?php echo $themesdealer['pfacebook-width']?>" data-height="<?php echo $themesdealer['pfacebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
				 </div>
			
				<?php endif; ?>   
				<?php if($themesdealer['pfacebook'] == 2 ): ?>
				<?php endif; ?>

                <!------------ Tab Close -------------->

                <section class="single_widget_section">
					<?php dynamic_sidebar('single_sidebar')?>
				</section>

                










            </div>
        </div>

    </div>
</section>

<?php get_footer(); 
			?>