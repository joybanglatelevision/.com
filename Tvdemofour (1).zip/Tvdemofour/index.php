<?php get_header();
global $themesdealer;
get_template_part('head');
?>

<!------------ Main Body Section  Start-------------->

<section class="main_body_section">
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
<div class="container website_body">			
<?php endif; ?>   
<?php if($themesdealer['full-body-website'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	

<div class="row">
<div class="col-md-9 col-sm-9">




<?php
$layout = $themesdealer['homepage-section']['Show'];
if ($layout): foreach ($layout as $key=>$value) {
switch($key) {
case 'section-one': get_template_part('assets/file/page/section-one');
break;

case 'section-two': get_template_part('assets/file/page/section-two');
break;

case 'section-three': get_template_part('assets/file/page/section-three');
break;

case 'section-four': get_template_part('assets/file/page/section-four');   
break;

case 'section-five': get_template_part('assets/file/page/section-five');   
break;

case 'section-six': get_template_part('assets/file/page/section-six');   
break;

case 'section-seven': get_template_part('assets/file/page/section-seven');
break;

case 'section-eight': get_template_part('assets/file/page/section-eight'); 
break;

case 'section-nine': get_template_part('assets/file/page/section-nine');   
break;

case 'section-ten': get_template_part('assets/file/page/section-ten');   
break;

case 'section-eleven': get_template_part('assets/file/page/section-eleven');   
break;

case 'section-twelve': get_template_part('assets/file/page/section-twelve');   
break;

case 'section-thirteen': get_template_part('assets/file/page/section-thirteen');   
break;

case 'section-fourteen': get_template_part('assets/file/page/section-fourteen');   
break;

}
}
endif;
?>	



</div>

<?php 
get_template_part('assets/file/page/sidebar');
?>

</div>

</div>
</section>



<?php get_footer(); 
?>