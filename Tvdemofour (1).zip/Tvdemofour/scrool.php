<?php global $themesdealer ?>

<!----------  Full Design start ---------->


<?php if($themesdealer['headline-button'] == 1 ): ?>

<section class="scrool_section">
<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	

<!------------ website scrool Start -------------->

<div class="row">
<div class="col-md-12 full_scrool">
<div class="col-xs-4 col-md-2 col-sm-3 front_scrool">
	<?php echo $themesdealer['hd_scroll_title'] ?>
</div>
<div class=" col-xs-8 col-md-9 col-sm-7 behind_scrool">
	<?php if($themesdealer['top_scroll_cat'] ==1 ): ?>
				
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php 
	$devs_home = new WP_Query(array(
	'post_type' => 'post',
	'posts_per_page' => $themesdealer['top_how_scroll'],
	));
	while($devs_home->have_posts()) : $devs_home->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['top_scroll_set'] == 2 ): ?>
	
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php
	$cat = $themesdealer['top_scroll_cat'];
	$category_name = get_the_category_by_id($cat);
	$category_name_link = get_category_link($cat);
	$themes_dealer = new WP_Query(array(
		'post_type' => 'post',
		'posts_per_page' => $themesdealer['top_how_scroll'],
		'cat' => $cat,

	));
	while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['top_scroll_set'] == 3 ): ?>
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php echo $themesdealer['top_notice_text'] ?>
	</marquee>
	
	<?php endif; ?>
</div>
<div class="col-md-1 col-sm-2 scrool_image">
	<a href="<?php echo $themesdealer['scroolone-link']['scroolone-url']; ?>" target="_blank"><img src="<?php echo $themesdealer['scroolone_upload']['url']?>"></a>
</div>
</div>
</div>

<!------------ website scrool Close -------------->

</div>
</section>

<?php endif; ?>   
<?php if($themesdealer['headline-button'] == 2 ): ?>				
<?php endif; ?>	


<?php if($themesdealer['notice-button'] == 1 ): ?>

<section class="scrool_section">
<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	
<!------------ website scrool Start -------------->

<div class="row">
<div class="col-md-12 full_scrool">
<div class="col-xs-4 col-md-2 col-sm-3 front_scrool">
	<?php echo $themesdealer['scroll_title'] ?>
</div>
<div class=" col-xs-8 col-md-9 col-sm-7 behind_scrool">
	<?php if($themesdealer['bottom_scroll_set'] ==1 ): ?>
				
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php 
	$devs_home = new WP_Query(array(
	'post_type' => 'post',
	'posts_per_page' => $themesdealer['how_scroll'],
	));
	while($devs_home->have_posts()) : $devs_home->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['bottom_scroll_set'] == 2 ): ?>
	
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php
		$cat = $themesdealer['scroll_cat'];
		$category_name = get_the_category_by_id($cat);
		$category_name_link = get_category_link($cat);
		$themes_dealer = new WP_Query(array(
			'post_type' => 'post',
			'posts_per_page' => $themesdealer['how_scroll'],
			'cat' => $cat,

		));
	while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['bottom_scroll_set'] == 3 ): ?>
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php echo $themesdealer['notice_text'] ?>
	</marquee>
	
	<?php endif; ?>
</div>
<div class="col-md-1 col-sm-2 scrool_image">
	<a href="<?php echo $themesdealer['scrooltwo-link']['scrooltwo-url']; ?>" target="_blank"><img src="<?php echo $themesdealer['scrooltwo_upload']['url']?>"></a>
</div>
</div>
</div>

<!------------ website scrool Close -------------->

</div>
</section>

<?php endif; ?>   
<?php if($themesdealer['notice-button'] == 2 ): ?>				
<?php endif; ?>	

</section>
