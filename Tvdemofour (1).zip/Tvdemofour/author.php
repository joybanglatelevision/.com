<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>

<!------------ Main Body Section  Start-------------->

<section class="main_body_section">
	
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	

        
        <div class="row">
            <div class="col-md-9 col-sm-8">
               
               <section class="page_section">

                    <div class="archive_title">
                        <a href="<?php bloginfo('url');?>"><i class="fa fa-home" aria-hidden="true"></i> / 	</a> <?php the_author_meta('display_name')?> 
                    </div>
                    
                   <div class="row">
				   
				   <?php $i=0; ?>
							<?php if(have_posts()) : ?>
							<?php
							while(have_posts()) : the_post();?>	
							<?php if ($i ==0){?>
							
                       <div class="col-md-8 col-sm-7">
                            
                            <div class="box_shadow">
                                <div class="leadnews_image lead_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    <div class="content_padding">
                                    <div class="archive_height">
                                        <div class="archive_heading">
                                            <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                         </div>
                                     </div>
                                 </div>
                                </div>
                            </div>

                        </div>
						
						<?php }
						$i++;
						?>
						<?php endwhile; ?>
						<?php endif; ?>
								
                        <div class="col-md-4 col-sm-5">
							
							<?php $i=0; ?>
								<?php if(have_posts()) : ?>
								<?php
								while(have_posts()) : the_post();?>
								<?php if ($i !=0 and $i ==1 or $i ==2 ){?>
								
                            <div class="archive_box_shadow">
                                <div class="leadnews_image exclusive_image">
                                        <div class="news_video_sec">
                                            <a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
                                        </div>
                                        
                                        <div class="content_padding">
                                        <div class="lead_height_1">
                                            <div class="heading_2">
                                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                             </div>
                                         </div>
                                     </div>
                                    </div>
                             </div>
							 
							 <?php }
								$i++;
								?>
								<?php endwhile; ?>
								<?php endif; ?>
								
                             

                       </div>
                   </div>

                   <div class="row">
                       
					   <?php $i=0; ?>
						<?php if(have_posts()) : ?>
						<?php
						while(have_posts()) : the_post();?>			
						<?php if ($i !=0 and $i !=1 and $i !=2 ){?>
						
                       <div class="col-md-6 col-sm-6">
                           <div class="arcbox_shadow">
                                <div class="leadnews_image">
                                    <div class="news_video_sec">
                                        <a href="<?php the_permalink()?>">
											<?php if(has_post_thumbnail()){ 
												the_post_thumbnail();}
												else{?>
											<div class="news_video">
												<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
													<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
													echo wp_oembed_get( $url );?>
												</div>
											</div>
											<i class="fa fa-play" aria-hidden="true"></i>
											<?php } ?>
										</a>
                                    </div>
                                    <div class="content_padding">
                                        <div class="lead_height_1">
                                            <div class="heading_1">
                                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                             </div>
                                         </div>
                                     </div>
                                </div>
                            </div>
                       </div>
					   
					   <?php }
						$i++;
							?>
						<?php endwhile; ?>
                <?php endif; ?>          
                <div class="row"><div class="col-md-12"><?php wp_bootstrap_pagination(); ?></div></div>
						
                       
                   </div>

               </section> 

            </div>
			
            <div class="col-md-3 col-sm-4">
                
                <div class="author_dtails-sec">
                    <div class="author_name_profile">
                        <div class="author_title">
                            <?php echo $themesdealer['authortitle'] ?>
                        </div>
                        <div class="author_profile">
                            <ul>
                                <li><a href="<?php the_author_meta('facebook'); ?>" target="_blank" class="author_facebook"> <i class="fa fa-facebook"></i></a></li>
                                <li><a href="<?php the_author_meta('twitter'); ?>" target="_blank" class="author_twitter"> <i class="fa fa-twitter"></i></a></li>
                                <li><a href="<?php the_author_meta('instagram'); ?>" target="_blank" class="author_instagram"> <i class="fa fa-instagram"></i></a></li>
                                <li><a href="<?php the_author_meta('linkedin'); ?>" target="_blank" class="author_linkedin"> <i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="author_image">
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), $default ); ?>
                        </div>
                        <div class="author_name">
                            <?php the_author_meta('display_name')?>
                        </div>
                        <div class="author_post">
                            <?php echo $themesdealer['authortotal'] ?> :-  <?php echo get_the_author_posts(); ?>
                        </div>
                        <div class="author_dtails">
                            <?php the_author_meta('description')?> 
                        </div>
                </div>
                <!------------ Tab Start -------------->

                <div class="tab-header">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo $themesdealer['last'] ?></a></li>
						<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"><?php echo $themesdealer['popular'] ?></a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div role="tabpanel" class="tab-pane in active" id="tab21">

                            <div class="news-titletab">
                                
								<?php							 
									$lastnews = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $themesdealer['lastpost'],
									'offset' =>0,
									));
									while($lastnews->have_posts()) : $lastnews->the_post();?>
									
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>
                                 
								 <?php endwhile ?>
								 
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                            <div class="news-titletab">
                                
								<?php	
								query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC');
								if (have_posts()) : while (have_posts()) : the_post();
								?>
								
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>

								<?php
								endwhile; endif;
								wp_reset_query();
								?>
										
                            </div>                                          
                        </div>
                    </div>
                </div>

                <!------------ Tab Close -------------->

                <section class="single_widget_section">
					<?php dynamic_sidebar('single_sidebar')?>
				</section>









            </div>
        </div>

    </div>
</section>

<?php get_footer(); 
			?>