
<?php global $themesdealer ?>


<!------------ Header Menu Section Start -------------->

<section class="hdr_menu_section">
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>
    <div class="row">
        <div class="col-xs-10 col-md-11 col-sm-11">
            <div id="menu-area" class="menu_area">
                <div class="menu_bottom">
                    <nav role="navigation" class="navbar navbar-default mainmenu">
                <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <!-- Collection of nav links and other content for toggling -->
                        <div id="navbarCollapse" class="collapse navbar-collapse">
                            <?php /* Primary navigation */
							wp_nav_menu( array(
						   'theme_location' => 'main-menu',
						   'menu_class'    => 'nav navbar-nav',
						   'fallback_cb' => 'default_main_menu',
						   'walker' => new wp_bootstrap_navwalker())
							  );
							?>
                        </div>
                    </nav>
                                
                </div><!-- /.header_bottom -->

            </div>
        </div>

        

        <div class=" col-xs-2 col-md-1 col-sm-1">
            <div class="search_box">
                <div class="search-icon-holder"> <a href="#" class="search-icon" data-toggle="modal" data-target=".bd-example-modal-lg"><i class="fa fa-search" aria-hidden="true"></i></a>
                    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i class="fa fa-times-circle" aria-hidden="true"></i> </button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="search_box">
                                                     <form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
                                                    <input type="search" name="s" class="form-control input-sm" maxlength="64" placeholder="<?php echo $themesdealer['placeholder']?>"/>
                                                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search"></i> </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>





<!------------ Header Menu Section Close -------------->