<?php /* Template Name: Our team Page */ ?>
<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>




<!------------ Header Menu Section Close -------------->

<section class="main_body_section">
    
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
                 
                 <div class="page_section">
                 <div class="row">
                    
					
					<?php
					$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
					$args = array(
						'post_type' => 'team',
						'order' => 'ASC',
						'paged' => $paged
					); $the_query = new WP_Query($args); if( $the_query->have_posts() ) : ?> 
					<?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>
					
					
					
					<div class="familycol-md-3 col-sm-3">
                        <div class="team_sec">
                            <a href="<?php the_permalink();?>"><?php if(has_post_thumbnail()){ 
								the_post_thumbnail();}
								?></a>
                            <div class="team_height"> 
                              <div class="team_title"> <a href="<?php the_permalink();?>"> <?php the_title() ?> </a> </div>
                              <div class="team_sub_title">  <?php echo get_post_meta(get_the_ID(),'des_text', true); ?> </div>
                            </div>
                        </div>
                    </div>
					
					<?php endwhile; ?>
					
                </div>
				
				<div class="row">
					 <div class="col-md-12 options">

						<!-- pagination -->
						<ul class="pagination pull-left">
						<li> <?php echo get_previous_posts_link ('<span class="glyphicon glyphicon-arrow-left"></span>'); ?></li>
							<li> <?php echo get_next_posts_link ('<span class="glyphicon glyphicon-arrow-right"></span>', $the_query->max_num_pages ); ?></li>
							
						</ul>

					</div>
				</div>
				<!-- /.options -->  

				<?php wp_reset_postdata(); ?>

				<?php endif; ?>

            </div>
            </div>
        </section>


    <!----------  Home Section Section Close ----------> 
	
	<?php get_footer();?>
	