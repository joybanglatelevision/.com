
<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>




<!------------ Header Menu Section Close -------------->

<section class="main_body_section">
    
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
                 
                 <div class="page_section">
                 <div class="row">
                    <div class="col-md-9 col-sm-9">
                        
						<?php if(have_posts()) : ?>
					<?php while(have_posts()) : the_post(); ?>
					
                        <div class="row">
                            <div class="col-md-5 col-sm-5">
                                <div class="team_img">
									<a href="<?php echo get_the_post_thumbnail_url();?>" data-lightbox="myimage"> 	<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										?>
									</a>
                                </div>
                            </div>
                            <div class="col-md-7 col-sm-7">
                                <div class="team_dtails_sec">
                                    <div class="sngl_team_title">  <?php the_title() ?>  </div>
                                    <div class="sngl_team_sub_title">  <?php echo get_post_meta(get_the_ID(),'des_text', true); ?> </div>
                                    <div class="team_dtails">
										<?php the_content();?>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						<?php endwhile;?>
					<?php endif;?>

                    </div>

                    <div class="col-md-3 col-sm-3">
                        
						<?php if($themesdealer['pfacebook'] == 1 ): ?>
							
							<div class="cat_title">
								 <?php echo $themesdealer['facebook-title'] ?>  
							</div>
											
							<div class="fb-root">
								<script>(function(d, s, id) {
								  var js, fjs = d.getElementsByTagName(s)[0];
								  if (d.getElementById(id)) return;
								  js = d.createElement(s); js.id = id;
								  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
								  fjs.parentNode.insertBefore(js, fjs);
								}(document, 'script', 'facebook-jssdk'));</script>
								<div class="fb-page" data-href="<?php echo $themesdealer['pfacebook-link']['pface-url']; ?>" data-tabs="timeline" data-width="<?php echo $themesdealer['pfacebook-width']?>" data-height="<?php echo $themesdealer['pfacebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
							 </div>
						
							<?php endif; ?>   
							<?php if($themesdealer['pfacebook'] == 2 ): ?>
							<?php endif; ?>
							
							
							
							
                    </div>
                    
                </div>

            </div>
            </div>
        </section>


    <!----------  Home Section Section Close ----------> 


 <?php get_footer();?>